- .local_share_fish については, $HOME/.local/share/fish として配置すること。
- fzf は ./install として ./bin/fzf を作成し、$PATH に通すこと。


