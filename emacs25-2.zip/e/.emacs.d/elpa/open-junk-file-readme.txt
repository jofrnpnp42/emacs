M-x `open-junk-file' opens a new file whose filename is derived from
current time.  You can write short program in it.  It helps to
try-and-error programs.

For example, in Emacs Lisp programming, use M-x `open-junk-file'
instead of *scratch* buffer.  The junk code is SEARCHABLE.

In Ruby programming, use M-x `open-junk-file' and
write a script with xmpfilter annotations.  It is the FASTEST
methodology to try Ruby methods, Irb is not needed anymore.
Xmpfilter is available at http://eigenclass.org/hiki/rcodetools
